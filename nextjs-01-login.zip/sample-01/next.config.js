module.exports = {
  poweredByHeader: false
};
